# Dictcc commandline tool

This tool enables the use of dictcc over the commandline.

	python3 dictcc.py <word>
	
## Requirements
Requires [requests](https://pypi.org/project/requests/), [tabulate](https://bitbucket.org/astanin/python-tabulate), and [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/).
